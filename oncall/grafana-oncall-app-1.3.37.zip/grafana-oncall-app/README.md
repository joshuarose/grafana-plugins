# Grafana OnCall

Developer-Friendly
Alert Management
with Brilliant Slack Integration

- Connect monitoring systems
- Collect and analyze data
- On-call rotation
- Automatic escalation
- Never miss alerts with calls and SMS

## Documentation

- [On Github](http://github.com/grafana/oncall)
- [Grafana OnCall](https://grafana.com/docs/oncall/latest/)
